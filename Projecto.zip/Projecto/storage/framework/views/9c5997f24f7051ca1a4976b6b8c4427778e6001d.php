<?php $__env->startSection('main'); ?>
	<main>
		<section>
			<h2> Cuerdas </h2>
		</section>

		<section style="color:white">
			<table class="table col-xs-10 col-xs-offset-1 col-md-8 col-md-offset-2">
				<tr>
					<th>Nombre</th>
					<th>Precios</th>
					<th>Acciones</th>
				</tr>
				<tbody class="table-striped table-hover">
					<?php $__currentLoopData = $cuerdas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuerda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($cuerda->name); ?></td>
							<td><?php echo e($cuerda->price); ?></td>
							<td><a href="/cuerda/<?php echo e($cuerda->id); ?>/edit">Editar</a><a href="/cuerda/<?php echo e($cuerda->id); ?>/delete">Eliminar</a></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</section>

		<section>

		</section>
	</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masterPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>