<?php $__env->startSection('main'); ?>
<main>
	<section>
		<article class="Instrumento">
			<h2> <?php echo e($cuerda->name); ?> </h2>
			<img src="<?php echo e($cuerda->thumbnail); ?>" alt="">
			<p> <?php echo e($cuerda->description); ?> </p>
			<h3>$<?php echo e($cuerda->price); ?></h3>
		</article>
	</section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masterPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>