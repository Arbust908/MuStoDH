

<?php $__env->startSection('main'); ?>
<main>
<section>

<fieldset class="inicio-sesion">
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2 sing-in-master">
				<img src="/images/logo.png" alt="logotipo" class="logo sing-in">

				<form class="form-horizontal" method="POST" action="<?php echo e(url('/cuerda').'/'.$cuerda[0]->id.'/edit'); ?>" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

					<input name="_method" type="hidden" value="PUT">



					<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
						<label for="name" class="sing-in">:Nombre</label>
						<input id="name" type="text" class="form-control" name="
						name" value="<?php echo e($cuerda[0]->name); ?>"  autofocus placeholder="Agregar Nombre">

						<?php if($errors->has('name')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('name')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
						<label for="name" class="sing-in">Agregar Descripcion: </label>
						<input id="name" type="text" class="form-control" name="description" value="<?php echo e($cuerda[0]->description); ?>"  placeholder="Agregar una Descripcion">

						<?php if($errors->has('description')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('description')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="form-group<?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
						<label for="name" class="sing-in">Agregar precio: </label>
						<input id="name" type="name" class="form-control" name="price"  placeholder="Precio" value="<?php echo e($cuerda[0]->price); ?>">

						<?php if($errors->has('price')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('price')); ?></strong>
							</span>
						<?php endif; ?>
					</div>

					<div class="form-group <?php echo e($errors->has('thumbnail') ? ' has-error' : ''); ?>">

						<label for="name" class="sing-in">Agregar Foto: </label>
						<input id="name" type="file" class="form-control" name="thumbnail" placeholder="Agregar Foto">
						<?php if($errors->has('thumbnail')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('thumbnail')); ?></strong>
							</span>
						<?php endif; ?>

					</div>


					<div class="form-group">
						<button class="btn btn-primary" type="submit">Actualizar Instrumento</button>
					</div>

				</form>

				<form class="form-horizontal" method="POST" action="<?php echo e(url('/cuerda').'/'.$cuerda[0]->id.'/delete'); ?>" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

					<input name="_method" type="hidden" value="DELETE">
					<button class="btn btn-danger" type="submit">Eliminar Instrumento</button>
				</form>
			</div>
		</div>
	</div>
</fieldset>

</section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masterPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>