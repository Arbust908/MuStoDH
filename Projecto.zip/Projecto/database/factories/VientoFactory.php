<?php

use Faker\Generator as Faker;

$factory->define(App\Viento::class, function (Faker $faker) {
    return [
        //
    ];
});
