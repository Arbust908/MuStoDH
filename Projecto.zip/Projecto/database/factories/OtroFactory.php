<?php

use Faker\Generator as Faker;

$factory->define(App\Otro::class, function (Faker $faker) {
    return [
        //
    ];
});
