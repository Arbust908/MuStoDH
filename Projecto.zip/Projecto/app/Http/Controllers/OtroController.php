<?php

namespace App\Http\Controllers;

use App\Otro;
use Illuminate\Http\Request;

class OtroController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Otro  $otro
     * @return \Illuminate\Http\Response
     */
    public function show(Otro $otro)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Otro  $otro
     * @return \Illuminate\Http\Response
     */
    public function edit(Otro $otro)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Otro  $otro
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Otro $otro)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Otro  $otro
     * @return \Illuminate\Http\Response
     */
    public function destroy(Otro $otro)
    {
        //
    }
}
