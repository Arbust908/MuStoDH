<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Otro extends Model
{
    //
}
